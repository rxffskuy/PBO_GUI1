﻿namespace Dekstop_Datagridview
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            Nama = new DataGridViewTextBoxColumn();
            NIP = new DataGridViewTextBoxColumn();
            Gaji = new DataGridViewTextBoxColumn();
            TanggalLahir = new DataGridViewTextBoxColumn();
            TempatLahir = new DataGridViewTextBoxColumn();
            Bidang = new DataGridViewTextBoxColumn();
            noTelp = new DataGridViewTextBoxColumn();
            btnTambah = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox5 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Nama, NIP, Gaji, TanggalLahir, TempatLahir, Bidang, noTelp });
            dataGridView1.Location = new Point(14, 16);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(875, 467);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Nama
            // 
            Nama.HeaderText = "Nama";
            Nama.MinimumWidth = 10;
            Nama.Name = "Nama";
            Nama.ReadOnly = true;
            Nama.Width = 200;
            // 
            // NIP
            // 
            NIP.HeaderText = "NIP";
            NIP.MinimumWidth = 10;
            NIP.Name = "NIP";
            NIP.ReadOnly = true;
            NIP.Width = 200;
            // 
            // Gaji
            // 
            Gaji.HeaderText = "Gaji";
            Gaji.MinimumWidth = 10;
            Gaji.Name = "Gaji";
            Gaji.ReadOnly = true;
            Gaji.Width = 200;
            // 
            // TanggalLahir
            // 
            TanggalLahir.HeaderText = "Tanggal Lahir";
            TanggalLahir.MinimumWidth = 10;
            TanggalLahir.Name = "TanggalLahir";
            TanggalLahir.ReadOnly = true;
            TanggalLahir.Width = 200;
            // 
            // TempatLahir
            // 
            TempatLahir.HeaderText = "Tempat Lahir";
            TempatLahir.MinimumWidth = 10;
            TempatLahir.Name = "TempatLahir";
            TempatLahir.ReadOnly = true;
            TempatLahir.Width = 200;
            // 
            // Bidang
            // 
            Bidang.HeaderText = "Bidang";
            Bidang.MinimumWidth = 10;
            Bidang.Name = "Bidang";
            Bidang.ReadOnly = true;
            Bidang.Width = 200;
            // 
            // noTelp
            // 
            noTelp.HeaderText = "No. Telepon";
            noTelp.MinimumWidth = 10;
            noTelp.Name = "noTelp";
            noTelp.ReadOnly = true;
            noTelp.Width = 200;
            // 
            // btnTambah
            // 
            btnTambah.Location = new Point(778, 541);
            btnTambah.Margin = new Padding(3, 4, 3, 4);
            btnTambah.Name = "btnTambah";
            btnTambah.Size = new Size(86, 31);
            btnTambah.TabIndex = 1;
            btnTambah.Text = "Tambah";
            btnTambah.UseVisualStyleBackColor = true;
            btnTambah.Click += btnTambah_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(32, 493);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(203, 27);
            textBox1.TabIndex = 3;
            textBox1.TextChanged += textBox1_TextChanged_1;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(32, 532);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(203, 27);
            textBox2.TabIndex = 4;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(304, 494);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(171, 27);
            textBox5.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 497);
            label1.Name = "label1";
            label1.Size = new Size(273, 20);
            label1.TabIndex = 8;
            label1.Text = "Triantono Adi Prambodo 222410101061\n";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 536);
            label2.Name = "label2";
            label2.Size = new Size(251, 20);
            label2.TabIndex = 9;
            label2.Text = "Rafief Jadma Amadia 222410101091";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(314, 496);
            label3.Name = "label3";
            label3.Size = new Size(278, 20);
            label3.TabIndex = 10;
            label3.Text = "James Emanuel Manggoa 222410101081\n";
            label3.Click += label3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox5);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(btnTambah);
            Controls.Add(dataGridView1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btnTambah;
        private DataGridViewTextBoxColumn Nama;
        private DataGridViewTextBoxColumn NIP;
        private DataGridViewTextBoxColumn Gaji;
        private DataGridViewTextBoxColumn TanggalLahir;
        private DataGridViewTextBoxColumn TempatLahir;
        private DataGridViewTextBoxColumn Bidang;
        private DataGridViewTextBoxColumn noTelp;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox5;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}